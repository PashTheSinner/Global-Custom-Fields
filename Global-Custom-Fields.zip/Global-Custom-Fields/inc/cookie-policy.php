<?php 
$cookie = '<p>[gdpr_business_name] (&ldquo;us&rdquo;, &ldquo;we&rdquo;, or &ldquo;our&rdquo;) uses cookies on [gdpr_business_name] (the &ldquo;Service&rdquo;). By using the Service, you consent to the use of cookies.
	<br>Our Cookies Policy explains what cookies are, how we use cookies, how third-parties we may partner with may use cookies on the Service, your choices regarding cookies and further information about cookies.</p>

<p>&nbsp;</p>

<p>What are cookies
	<br>Cookies are small pieces of text sent by your web browser by a website you visit. A cookie file is stored in your web browser and allows the Service or a third-party to recognize you and make your next visit easier and the Service more useful to you.</p>

<p>&nbsp;</p>

<p>How [gdpr_business_name] uses cookies
	<br>When you use and access the Service, we may place a number of cookies files in your web browser.
	<br>We use cookies for the following purposes: to enable certain functions of the Service, to provide analytics, to store your preferences, to enable advertisements delivery, including behavioral advertising.
	<br>We use both session and persistent cookies on the Service and we use different types of cookies to run the Service:
	<br>&ndash; Essential cookies. We may use essential cookies to authenticate users and prevent fraudulent use of user accounts.</p>

<p>&nbsp;</p>

<p>Third-party cookies
	<br>In addition to our own cookies, we may also use various third-parties cookies to report usage statistics of the Service, deliver advertisements on and through the Service, and so on.</p>

<p>&nbsp;</p>

<p>What are your choices regarding cookies
	<br>If you&rsquo;d like to delete cookies or instruct your web browser to delete or refuse cookies, please visit the help pages of your web browser.
	<br>Please note, however, that if you delete cookies or refuse to accept them, you might not be able to use all of the features we offer, you may not be able to store your preferences, and some of our pages might not display properly.</p>

<p>&nbsp;</p>

<p>Where can your find more information about cookies
	<br>You can learn more about cookies and the following third-party websites:
	<br>AllAboutCookies: http://www.allaboutcookies.org/
	<br>Network Advertising Initiative: http://www.networkadvertising.org/</p>

<table border="0" cellpadding="0" cellspacing="0" width="756">
	<tbody>
		<tr>
			<td class="xl66" height="20">
				<br>
			</td>
		</tr>
	</tbody>
</table>';
?>