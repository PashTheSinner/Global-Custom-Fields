<?php 

$terms = '<p>Welcome to the website for [gdpr_business_name].
	<br>By using this website, you agree to comply with the following terms and conditions of use. Our terms and conditions along with our privacy policy dictate the relationship between [gdpr_business_name] and you in relation to this website. Should you disagree with our terms and conditions, please desist from using our website immediately.</p>

<p>&nbsp;</p>

<p>The term &lsquo;[gdpr_business_name]&rsquo; or &lsquo;us&rsquo; or &lsquo;we&rsquo; refers to the owner of the website, and our registered office. &lsquo;You&rsquo; relates to the visitor or user of our website.</p>

<p>&nbsp;</p>

<p>By using this site, you agree to the following terms of use:</p>

<p>All information and content listed on this website is for general information use only. It is subject to change at any given time without prior notice.</p>

<p>&nbsp;</p>

<p>We use cookies on this website to monitor the browsing preferences of visitors/users. If you agree to cookies being stored, the information may be stored by our company for external third-parties use.
	<br>We or any related third parties do not give any guarantee or warranty with regards to the performance, exactness, accuracy, appropriateness of the resources or materials offered on this website for any specific reason.
	<br>By using this website, you accept that materials and information may occasionally be inaccurate or contain errors of which we exclude liability for said errors or inaccuracies to the fullest extent permitted by law.
	<br>By using materials or information sourced from this website will be at your risk for which is not liable. It will be your responsibility to make sure that information, services, products offered by via our website meets your needs.
	<br>All materials on this website are either owned or licensed to [gdpr_business_name]. Said materials includes but is not limited to graphics, appearance, design, and layout. Reproduction of said materials is strictly prohibited unless this is in relation with a notice of copyright that forms part of these terms and conditions.
	<br>All trademarks that are reproduced in/on this website, which are not the property of , or licensed to the operator, are acknowledged on the website. Any unauthorised use of this website may be a criminal offence and/or may give claim for damages.
	<br>At [gdpr_business_name], we may place external third-party links on our website which are provided for the convenience and benefit of the user. Said links does not show an endorsement of [gdpr_business_name] of said website(s). We do not accept responsibility for the content of these third-party linked website(s).
	<br>Your use of this website and any dispute arising out of such use of the website is subject to the laws of England, Northern Ireland, Scotland and Wales.</p>

<table border="0" cellpadding="0" cellspacing="0" width="756">
	<tbody>
		<tr>
			<td class="xl66" height="20">
				<br>
			</td>
		</tr>
	</tbody>
</table>';
?>