// jQuery(document).ready(function($){
    
// var uiIconOne ='https://www.24hr-services.co.uk/wp-content/uploads/2019/02/cash_or_card.png';

// var uiIconTwo ='https://www.24hr-services.co.uk/wp-content/uploads/2019/02/training.png';

// var uiIconThree ='https://www.24hr-services.co.uk/wp-content/uploads/2019/02/satisfaction_guaranteed.png';

// var uiIconFour ='https://www.24hr-services.co.uk/wp-content/uploads/2019/02/free_quote_15241311741.png';

// var uiIconFive ='https://www.24hr-services.co.uk/wp-content/uploads/2019/02/advice.png';

// var uspTextOne = 'Some Rando Text1';
// var uspTextTwo ='Some Rando Text2';
// var uspTextThree ='Some Rando Text3';
// var uspTextFour ='Some Rando Text4';
// var uspTextFive ='Some Rando Text5';

// $( ".header_top_bottom_holder" ).append( "<div id='uspbar'></div>" );

//document.getElementById("uspbar").innerHTML = '<div class="uspcontainer"><div class="uspbox one"><div class="uspboxicon"><img src="' + uiIconOne+ '"></div><div class="uspboxtext">' + uspTextOne + '</div></div><div class="uspbox"><div class="uspboxicon"><img src="' + uiIconTwo+ '"></div><div class="uspboxtext">' + uspTextTwo + '</div></div><div class="uspbox"><div class="uspboxicon"><img src="' + uiIconThree+ '"></div><div class="uspboxtext">' + uspTextThree + '</div></div><div class="uspbox"><div class="uspboxicon"><img src="' + uiIconFour + '"></div><div class="uspboxtext">' + uspTextFour + '</div></div><div class="uspbox"><div class="uspboxicon"><img src="' + uiIconFive + '"></div><div class="uspboxtext">' + uspTextFive + '</div></div></div>'; 

});



